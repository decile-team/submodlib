def square(num):
    '''
    Calculate square of a number
    :param  num: number whose square is desired
    :return: square of num
    '''
    return num*num
